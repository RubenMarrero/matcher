<?php

/**
 * credenciales de conexion a la base de datos
 */
abstract class credentials
{
  const host = "localhost";
  const user = "usuario";
  const password = "password";
  const database = "db_articulos";
}
