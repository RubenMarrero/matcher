-- Tanto crear las tablas como importar los datos desde los archivos csv
-- podria automatizarse con los datos de DatabaseMapper

USE db_articulos;
LOAD DATA LOCAL INFILE './import/csv_import_files/idiomas.csv' REPLACE INTO TABLE idiomas
  CHARACTER SET utf8mb4
  FIELDS TERMINATED BY ',' 
  ENCLOSED BY '"' 
  LINES TERMINATED BY '\n'
  ( idioma );
LOAD DATA LOCAL INFILE './import/csv_import_files/usuarios.csv' REPLACE INTO TABLE usuarios
  CHARACTER SET utf8mb4
  FIELDS TERMINATED BY ',' 
  ENCLOSED BY '"' 
  LINES TERMINATED BY '\n'
  ( nombre_usuario, password, email, idioma_preferido );
LOAD DATA LOCAL INFILE './import/csv_import_files/articulos.csv' REPLACE INTO TABLE articulos
  CHARACTER SET utf8mb4
  FIELDS TERMINATED BY ',' 
  ENCLOSED BY '"' 
  LINES TERMINATED BY '\n'
  ( id_usuario );
LOAD DATA LOCAL INFILE './import/csv_import_files/articulos_lang.csv' REPLACE INTO TABLE articulos_lang
  CHARACTER SET utf8mb4
  FIELDS TERMINATED BY ',' 
  ENCLOSED BY '"' 
  LINES TERMINATED BY '\n'
  ( id_articulo, id_idioma, titulo, contenido );
