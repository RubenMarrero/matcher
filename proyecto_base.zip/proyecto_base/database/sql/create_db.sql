-- Si la base de datos ya existe dará error, pero si se está intentando 
-- crear la base de datos, que exista sería inesperado y podría
-- considerarse un error o que algún imprevisto ha sucedido.
-- De querer evitarlo simplemente remplazaríamos la primera línea por:
--   CREATE DATABASE IF NOT EXISTS db_articulos CHARACTER SET utf8 COLLATE utf8mb4_unicode_ci;


-- Tanto crear las tablas como importar los datos desde los archivos csv
-- podria automatizarse con los datos de DatabaseMapper

CREATE DATABASE db_articulos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_articulos;

CREATE TABLE idiomas (
  id INT AUTO_INCREMENT,
  idioma VARCHAR(10),
  PRIMARY KEY(id)
);

CREATE TABLE usuarios (
  id INT AUTO_INCREMENT,
  nombre_usuario VARCHAR(40),
  password VARCHAR(40),
  email VARCHAR(40),
  idioma_preferido INT NOT NULL,
  fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(id),
  FOREIGN KEY(idioma_preferido) REFERENCES idiomas(id)
);

CREATE TABLE articulos (
  id INT AUTO_INCREMENT,
  id_usuario INT NOT NULL,
  fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY(id),
  FOREIGN KEY(id_usuario) REFERENCES usuarios(id)
);

CREATE TABLE articulos_lang (
  id INT AUTO_INCREMENT,
  id_articulo INT NOT NULL,
  id_idioma INT NOT NULL,
  titulo VARCHAR(40),
  contenido TEXT,
  PRIMARY KEY(id),
  FOREIGN KEY(id_articulo) REFERENCES articulos(id),
  FOREIGN KEY(id_idioma) REFERENCES idiomas(id)
);


