<?php

/**
 *  Con esta clase abstracta pretendo hacer una suerte de ENUM que enumere
 *  los distintos tipos de datos que recoge la aplicacion para que a la hora
 *  de validar los datos cuando haya que insertarlos en la DB haya un menor margen
 *  de error.
 * */

abstract class DataTypes 
{
  const primKey = "PRIMARY KEY";
  const forKey = "FOREIGN KEY";
  const char = "CHAR";
  const varchar = "VARCHAR";
  const text = "TEXT";
  const password = "CHAR"; // Se le trata diferente porque hay que cifrarla antes de almacenarla a diferencia de otros chars
  const email = "VARCHAR"; // Debe ser un email valido
  const fecha = "DATE";
}

/**
 *  Esta clase (DatabaseMapper) es el núcleo de esta estructura.
 *
 *  Se encarga de digerir (sanitizar, validar, cifrar) los datos
 *  segun los requerimentos de cada tipo de dato y posteriormente
 *  decidir si mandarselos a StorageAdapter para que opere con esos
 *  datos sobre la base de datos o instanciarlos en un objeto Modelo 
 *  que represente el tipo de objeto/dato complejo en cuestión
 *  (Usuario, Articulo, ... ).
 *
 *  Los modelos tienen como unica finalidad representar los datos.
 */
class DatabaseMapper
{
  
  public $adapter;
  private static $tableName_to_object = array(
    'usuarios'    => 'Usuario',
    'articulos'   => 'Articulo',
    'idiomas'     => 'Idioma'
  );

  static $tables = array('usuarios','articulos','idiomas','articulos_lang');

  /**
   *  Estas variables *_tables nos ayudan a 2 cosas:
   *    1) definen cuales son las columnas validas para cada tabla,
   *    2) guardan el tipo de dato que almacenan para poder validar
   *         los datos antes de insertarlos en la tabla. 
   *         Podria tambien tenerse en cuenta la longitud de los
   *         valores u otras cosas pero no lo veo tan relevante para 
   *         este ejemplo, la estructura sin embargo seguiria siendo
   *         la misma.
   * */
  static $usuarios_columns = array(
    'id'                => DataTypes::primKey,
    'nombre_usuario'    => DataTypes::varchar,
    'password'          => DataTypes::password,
    'email'             => DataTypes::email,
    'idioma_preferido'    => DataTypes::varchar,
    'fecha_creacion'      => DataTypes::fecha
  );
  static $idiomas_columns = array(
    'id'        => DataTypes::primKey,
    'idioma'    => DataTypes::varchar
  );
  static $articulos_columns = array(
    'id'                  => DataTypes::primKey,
    'id_usuario'          => DataTypes::forKey,
    'fecha_creacion'      => DataTypes::fecha
  );
  static $articulos_lang_columns = array(
    'id'              => DataTypes::primKey,
    'id_articulo'     => DataTypes::forKey,
    'id_idioma'       => DataTypes::forKey,
    'titulo'          => DataTypes::varchar,
    'contenido'       => DataTypes::text
  );
  /**
   * 
   */
  public function __construct( StorageAdapter $storage )
  {
    $this->adapter = $storage;
  }

  public function find( array $match, string $table )
  {
    $resultado = $this->adapter->find($match, $table);
    return $resultado;
  }

  public function insert( array $data, string $table )
  {
    $resultado = $this->adapter->insert($data, $table);
    return $resultado;
  }

  public function erase( array $match, string $table, boolean $unique=NULL )
  {
    $resultado = $this->adapter->delete($match, $table, $unique);
    return $resultado;
  }
  
  public function update( array $match, array $new, string $table )
  {
    $resultado = $this->adapter->update($match, $new, $table);
    return $resultado;
  }

  public function mapToModel( array $row, string $table)
  {
    $tableName = trim(strtolower($table));
    $className = DatabaseMapper::$tableName_to_object[$tableName];
    return new $className(...array_values($row));
  }

}
