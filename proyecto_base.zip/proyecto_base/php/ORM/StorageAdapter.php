<?php 

/**
 *  Esta es la unica clase que interactua directamente con la base de datos.
 */
class StorageAdapter
{

  public $db_object_abstraction;

  // Idealmente este número no debería de ser nunca superior a 1
  // en caso de que esto llegase a suceder debería de entenderse por qué
  // y saber explicar por qué es necesario que esa sea la mejor opción.
  // Para una estructura tan simple como esta nunca debería de ser más
  // de 1 y si llegase a serlo al no estarlo teniendo en cuenta habrán 
  // resultados inesperados.
  static $db_workers = 0;
  
  public function __construct( $host, $user, $password, $db='' )
  {
    $this->db_object_abstraction = new mysqli( $host, $user, $password, $db );
    if($this->db_object_abstraction->connect_error){
      die("ERROR al tratar de conectar con la base de datos.\n");
    } else {
      StorageAdapter::$db_workers++;
    }
  }

  public function find( array $match, string $tabla )
  {
    // validar columna y tabla
    $columna = key($match);

    // sanitizar el match que se va ejecutar en el query para evitar SQLi
    $valor = $match[$columna];

    $resultado = $this->db_object_abstraction->query("SELECT * from $tabla where $columna='$valor'");

    // Si hubo un error devolvemos false.
    if( false == $resultado ) { 
      // print "\nLa tabla o la columna que se trata buscar no existen"; 
      return false;
    }

    $resultado = $resultado->fetch_assoc();

    // Si no hubieron resultados devolvemos null.
    if( NULL == $resultado){ return NULL; }
    
    // password no deberia salir de esta clase. Al menos no sin querer.
    if (array_key_exists("password", $resultado)) {
      unset($resultado['password']);
    }

    return $resultado;
  }

  public function insert( array $data, string $tabla )
  {
    
  }

  public function erase( array $match, string $tabla, boolean $unique=NULL)
  {
    
  }

  /**
   * @param array $match contiene 1 clave y 1 valor por los cuales encontrar la
   *        fila de la tabla que queremos modificar.
   * @param array $new contiene un array cullas claves son las columnas a modificar
   *        y sus valores son los nuevos a actualizar.
   * @return true si el cambio se realiza con exito false si no.
   * */

  public function update( array $match, array $new, string $tabla)
  {
    
  }

}
