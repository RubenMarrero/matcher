<?php 

require __DIR__."/models/Usuario.php";
require __DIR__."/models/Articulo.php";
require __DIR__."/ORM/DatabaseMapper.php";
require __DIR__."/ORM/StorageAdapter.php";
require __DIR__."/../credentials/credentials.php";

  $db_mapper = new DataBaseMapper(new StorageAdapter(credentials::host, credentials::user, credentials::password, credentials::database)); 

  print "\nElige una tabla: ";
  $tabla = trim(fgets(STDIN));

  echo "Elige una columna para usar de filtro: ";
  $columna = trim(fgets(STDIN));

  echo "Elige un valor para hacer match: ";
  $match = trim(fgets(STDIN));

  $resultado = $db_mapper->find(array($columna => $match), $tabla);

  if($resultado){
    printf("\nTabla: $tabla\t|\tColumnas: %d\n",count($resultado));
    foreach( $resultado as $key => $value ){
      print "\tColumna: $key \n\tvalor: $value\n\n";
    }

    $ModeloDeLaTabla = $db_mapper->mapToModel($resultado, $tabla);

    $propiedades_modelo = $ModeloDeLaTabla->get_modelo();
    printf("\nObjeto modelo: %s\t|\tPropiedades: %d\n",get_class($ModeloDeLaTabla),count($propiedades_modelo));
    foreach( $propiedades_modelo as $key => $value ){ 
      print "\tpropiedad: $key \n\tvalor: $value\n\n";
    }
  } else {
    if( false === $resultado ) { 
     print "\nHubo algun error con la consulta a la base de datos. Comprueba que la tabla y la columna existen."; 
    }
    print "\nNo hubo ningun match\n\n";
  }

  
?>
