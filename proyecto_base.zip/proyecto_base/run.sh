#!/bin/bash

php ./php/mysqli.php
